import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split, StratifiedKFold, RandomizedSearchCV
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, accuracy_score, confusion_matrix, roc_auc_score
from sklearn.calibration import CalibratedClassifierCV
from imblearn.over_sampling import SMOTE
from imblearn.pipeline import Pipeline
import joblib

df = pd.read_csv("phishing.csv")
df.columns = df.columns.str.strip()

X = df.drop(["Index", "class"], axis=1)
y = df["class"]

print("🔍 Original class distribution:\n", y.value_counts(), "\n")

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)

print("🔧 Hyperparameter tuning with SMOTE and cross-validation...")

param_dist = {
    'clf__n_estimators': [100, 200, 300],
    'clf__max_depth': [None, 10, 20, 30],
    'clf__min_samples_split': [2, 5, 10],
    'clf__min_samples_leaf': [1, 2, 4],
    'clf__bootstrap': [True, False]
}

pipeline = Pipeline([
    ('smote', SMOTE(random_state=42)),
    ('clf', RandomForestClassifier(random_state=42, class_weight='balanced'))
])

skf = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)
search = RandomizedSearchCV(pipeline, param_distributions=param_dist, n_iter=20,
                            cv=skf, scoring='f1', n_jobs=-1, verbose=1, random_state=42)
search.fit(X_train, y_train)

print(f"✅ Best parameters: {search.best_params_}")

print("\n⚖️ Calibrating probabilities...")
calibrated_model = CalibratedClassifierCV(search.best_estimator_, cv=skf, method='isotonic')
calibrated_model.fit(X_train, y_train)

print("\n🧪 Evaluating calibrated model...")
y_pred = calibrated_model.predict(X_test)
y_proba = calibrated_model.predict_proba(X_test)

print("🎯 Accuracy on Test Data:", accuracy_score(y_test, y_pred))
print("📈 ROC-AUC:", roc_auc_score(y_test, y_proba[:, 1]))
print("\n📝 Classification Report:\n", classification_report(y_test, y_pred))
print("📊 Confusion Matrix:\n", confusion_matrix(y_test, y_pred))

joblib.dump(calibrated_model, "phishing_model.pkl")
print("💾 Calibrated model saved as phishing_model.pkl")

print("\n📌 Showing Feature Importances...")
rf_best = search.best_estimator_.named_steps['clf']
importances = rf_best.feature_importances_
feature_names = X.columns

plt.figure(figsize=(10, 8))
plt.barh(feature_names, importances)
plt.xlabel("Importance Score")
plt.title("Feature Importances from Random Forest")
plt.tight_layout()
plt.savefig("feature_importances.png")
print("📊 Feature importance chart saved as feature_importances.png")

def classify_website(features, model, feature_names):
    """
    Classify a website as 'phishing', 'safe', or 'suspicious/unknown' based on model prediction probabilities.
    """
    X_input = pd.DataFrame([features], columns=feature_names)

    proba = model.predict_proba(X_input)[0]
    class_labels = model.classes_

    proba_dict = {str(label): p for label, p in zip(class_labels, proba)}
    phishing_label = max(class_labels)
    legit_label = min(class_labels)

    phishing_conf = proba_dict.get(str(phishing_label), 0)
    legit_conf = proba_dict.get(str(legit_label), 0)

    if phishing_conf >= 0.7:
        return ("phishing", phishing_conf, proba_dict)
    elif legit_conf >= 0.7:
        return ("safe", legit_conf, proba_dict)
    else:
        return ("suspicious/unknown", max(phishing_conf, legit_conf), proba_dict)


print("\n🔎 Demo classification on a few test samples:")
for i in range(5):
    features = X_test.iloc[i].values
    label, conf, proba = classify_website(features, calibrated_model, X.columns)
    print(f"Sample {i+1}: Predicted as {label.upper()} (confidence: {conf:.2%}) | Probabilities: {proba}")
